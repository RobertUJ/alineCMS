<?php /*


-------------------------------------------------------------------------------------------
  CKEditor - Posted Data

  We are sorry, but your Web server does not support the PHP language used in this script.

  Please note that CKEditor can be used with any other server-side language than just PHP.
  To save the content created with CKEditor you need to read the POST data on the server
  side and write it to a file or a database.


  Copyright 2003-2012, CKSource - Frederico Knabben.
  All rights reserved.
-------------------------------------------------------------------------------------------




*/ include "assets/_posteddata.php"; ?>
