<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Tienda extends CI_Controller{

	private  $_menu = "";

	public function __construct(){
		parent::__construct();
		$this->load->model('model_post', 'post');
		$this->load->model('model_catalogos', 'catalogos');
    	$this->load->model('model_menus', 'menu');
    	$data['Menu_Principal'] =  $this->get_padres_vista(27);
        $this->_menu =  $this->load->view('public/helper/main_menu' , $data, True);
	}

	public function index(){
		$data['main_menu'] = $this->_menu;
		$data['productos'] = $this->catalogos->get_productos();
		$data['catalogo_panel'] = $this->catalogo_panel(1);
        $this->load->view('public/catalogo/home.php',$data);
	}

	public function producto($id){
		$data['Menu_Principal'] = $this->get_padres_vista(27);
        $data['main_menu'] = $this->load->view('public/helper/main_menu' , $data, True);
        $data['producto'] = $this->contenido_producto($id);
        $data['catalogo_panel'] = $this->catalogo_panel(1);
    	$this->load->view('public/catalogo/producto.php',$data);
	}

	public function get_padres_vista($idMenu = 0, $padre = 0){
        $items = $this->menu->get_ItemsMenu_front($idMenu,$padre);
        $nombre_menu = $this->menu->get_nombre_menu($idMenu);
        if($items->num_rows == 0 and $padre == 0){
            $elementos = "<ul><li>No hay items de menu en la base de datos.</li></ul>";
            return $elementos;
        }
        if($padre == 0){ 
            $mainMenu = $this->menu->get_mainMenu($idMenu); 
            $classMenu = ""; $idCssMenu =""; $atriMenu ="";
            if(! is_null($mainMenu->clase) ) $classMenu = "class='".$mainMenu->clase."'";
            if(strlen( trim($mainMenu->id_css) ) > 0 ){
                $subId = "id='".$mainMenu->id_css."'";
            }
            if(! is_null($mainMenu->atributos) ) $atriMenu = $mainMenu->atributos;
            $elementos = "<ul ".$classMenu." ".$idCssMenu." ".$atriMenu.">";
        }else{
            $elementos = "<ul class='dropdown-menu'>";
        }
        foreach($items->result() as $row){
            if( $row->is_logged == 'si' && ! $this->session->userdata('logged_in') ) continue;
            $hijos = $this->menu->get_hijos($idMenu,$row->idItem);
            $subClass =""; $subId = ""; $subAtri = "";
            if(! is_null($row->clase) ) $subClass = "class='".$row->clase."'";
            if(strlen( trim($row->id_css) ) > 0 ){
                $subId = "id='".$row->id_css."'";
            }
            if(! is_null($row->atri) ) $subAtri = $row->atri;
            $elementos .= "<li ".$subClass." ".$subId." ".$subAtri.">";
            $mhref = "";
            switch ($row->tipo) {
                case 1:
                    $mhref = base_url();
                    break;
                case 2:
                    $mhref = base_url('contacto');
                    break;
                case 3:
                    $tSlug = $this->menu->slug_actual($row->idpost);
                    $mhref = base_url($tSlug);
                    break;
                case 4:
                    $tSlug = $this->menu->slug_actual($row->idpost);
                    $mhref = base_url($tSlug);
                    break;
                case 5:
                    $mhref = base_url('blog');
                    break;
                case 6:
                    $mhref = $row->url;
                    break;
            }
            if(! $hijos > 0){
                $elementos .= "<a href='$mhref'>" . $row->titulo . "</a>";
            }else{
                $elementos .= "<a class='dropdown-toggle' data-toggle='dropdown' href='$mhref'>" . $row->titulo . "</a>";
            }

            if($hijos > 0){
                $elementos .= $this->get_padres_vista($idMenu,$row->idItem);
            }
            $elementos .= '</li>';  
        } 
        $elementos .='</ul>';
        return $elementos;
    } 

    public function catalogo_panel($id_catalogo){
    	$ids_categorias = "";
        $menu_cat = "";
        $titulo = "";
        $catalogo = $this->catalogos->get_catalogo_by_id($id_catalogo);
        foreach ($catalogo->result() as $cata){
            $titulo = $cata->titulo;
        }
		$productos = $this->catalogos->get_productos();
        $categorias = $this->catalogos->get_categorias();
		if($productos != FALSE){
            foreach ($categorias->result() as $cat){
                foreach ($productos->result() as $prod){
                    $array_prod = explode(",", $prod->id_categorias_cat);
                    if (in_array($cat->id, $array_prod)){
                        if ($ids_categorias == "")
                            $ids_categorias = $cat->id;
                        else
                            $ids_categorias .= "," . $cat->id;
                        break;
                    }
                }
            }
		}
        $str_categorias = "";
        if ($ids_categorias != "")
        {
            $categorias = $this->catalogos->get_categorias_para_catalogo($ids_categorias);
            foreach ($categorias->result_object() as $row){
                $url = base_url('/tienda/categoria')."/".$row->id;
                $str_categorias .= "<li class='categoria'><a href='".$url."'>$row->titulo</a></li>";
            }
            $menu_cat = "<div class='span3' ><ul class='catalogo'><a href='".base_url('tienda')."'>".$titulo."</a>".$str_categorias."</ul></div>";
        }
        return $menu_cat;
    }

    public function contenido_producto($id){
        $contenido = "";
        $li = "";
        $img = "";
        $imgs = "";
        $imgs_temp = "";
        $producto = $this->catalogos->get_producto_by_id($id);
        foreach ($producto->result() as $row){
            $dir = base_url('/assets/img/catalogo').'/'.$row->img_cat;//$_SERVER['DOCUMENT_ROOT']."/vdiamonds2/assets/img/catalogo/";
            if ($row->imagenes != "")
            {
                $imgs_temp = $row->imagenes;
                $img = substr($imgs_temp, 1, -1);
                $imgs = explode(",", $img);
                for ($i = 0; $i < count($imgs); $i++) { 
                    $dir2 = base_url('/assets/img/catalogo').'/'.$imgs[$i];
                    $li .= '<li><img class="img-mini" src="'.$dir2.'"></img></li>';
                }
            }
            $contenido = '  <div class="span9 galeria">
                                <div class="row">
                                <div id="imagen">
                                    <img width="380px" height="300px" id="img-pre" src="'.$dir.'" alt="'.$row->nombre.'">
                                    <!--label>'.$row->nombre.'</label-->
                                </div>
                                <div id="descripcion">
                                    <h2>'.$row->nombre.'</h2>
                                    <p>'.$row->descripcion.'</p>
                                </div>
                                </div>
                                <div id="mini-galeria">
                                    <ul class="detalles-vista">
                                        '.$li.'
                                    </ul>
                                </div>
                            </div>';            
        }
        return $contenido;
    }

    public function categoria($id){
        $data['main_menu'] = $this->_menu;
        $data['productos'] = $this->catalogos->get_productos_by_id_categoria($id);
        $data['catalogo_panel'] = $this->catalogo_panel(1);
        $this->load->view('public/catalogo/home.php',$data);
    }
}