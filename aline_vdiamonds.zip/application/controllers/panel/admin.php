<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/blog
	 *	- or -  
	 * 		http://example.com/index.php/blog/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *e
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/blog/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function __construct(){
		parent::__construct();
	}
			
	public function index($estado = ""){
		$data['no_existe'] = "";
		$data['head'] = $this->alinecms->get_head('Inicio sesion administradores',TRUE);
		$data['footer'] = $this->alinecms->get_footer(TRUE);
		$data['header'] = $this->alinecms->get_header("_0");

		if($estado != ""){
			$data['no_existe'] = "Por favor verifique sus datos he intentelo de nuevo";
		}

		if(! $this->alinecms->is_LoggedAdmin()){
			$this->load->view('admin/inicio_sesion',$data);	
		}else{
			$data['header'] = $this->alinecms->get_header("--");
			$this->load->view('admin/escritorio',$data);
		}
	}


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */