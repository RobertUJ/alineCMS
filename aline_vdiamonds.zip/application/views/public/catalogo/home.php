		<?php $this->load->view('/public/helper/head.php'); ?>
		<?=$main_menu?>
			<div id="fondo">
            <div id="back-wrapper" class="container">
                <div id="home-wrapper" class="span12">
                <div id="contenido-txt">
                <h2>CATEGORÍAS</h2>
				<?=$catalogo_panel?>
				<div class="span9 galeria">
					<div class="row">
						<ul>
				<?php
					$cont = 0;
					$cierre = true;
					if ($productos != FALSE)
					{
						foreach ($productos->result() as $row){
							$cont++;
							$url = base_url("tienda/producto/$row->id");
							$img = base_url("assets/img/catalogo/$row->img_cat");
						?>
							<li class="span4 producto">
								<a href="<?php echo $url; ?>">
									<img src="<?php echo $img; ?>"><?php echo $row->nombre;?>
								</a>
							</li>
						<?php 
							if ($cont%3 == 0)
							{
								$cierre = false; ?>
									</ul>
								</div>
								<div class="row">
									<ul>
							<?php }
							else
								$cierre = true;
						}
						if ($cierre)
						{ ?>
								</ul>
							</div>
						<?php }
					}
				?>
				</div>

				
 	            </div>  
                <div id="banners-hor">
                <?php //$this->load->view('/public/helper/banners'); ?>
                </div>
            </div>
            </div>
			<!-- Le main content -->
			<div>
				<section>
					<article></article>
				</section>
<?php /*$this->load->view('public/helper/int.php'); */?>
				<!-- Le sidebar -->
				<aside>
					
				</aside>
			</div>
	<div id="footer-wrapper">
  
    </div>		
	<!-- Le footer && Javascript files -->
	<!-- ******************************************* -->
	<!-- Le head.php  ==> location: application/views/public/helper/footer.php -->
	
	</div>
	<?php $this->load->view('public/helper/footer.php'); ?>
	<!-- ******************************************* -->
 
	</body>
</html>