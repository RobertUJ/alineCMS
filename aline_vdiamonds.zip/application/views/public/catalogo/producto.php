		<?php $this->load->view('/public/helper/head.php'); ?>
		<?=$main_menu?>
			<div id="fondo">
            <div id="back-wrapper" class="container">
                <div id="home-wrapper" class="span12">
                <div id="contenido-txt">
                <h2>CATEGORÍAS</h2>
				<?=$catalogo_panel?>                	
				<?=$producto?>
 	            </div>  
                <div id="banners-hor">
                </div>
            </div>
            </div>
			<div>
				<section>
					<article></article>
				</section>
<?php /*$this->load->view('public/helper/int.php'); */?>
				<aside>
				</aside>
			</div>
	<div id="footer-wrapper">
    </div>		
	<?php $this->load->view('public/helper/footer.php'); ?>
	</body>
	<script type="text/javascript">
	function cambiar_imagen(e)
	{
		e.preventDefault();
		var src = $(this).attr('src');
		$("#img-pre").attr('src',src);
	}
	function inicio()
	{
		$(".img-mini").on("mouseenter",cambiar_imagen);
	}
	$(document).on("ready",inicio);
</script>
</html>
