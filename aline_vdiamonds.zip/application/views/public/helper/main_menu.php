<div class="container">
<header>
	<div class="redes">
		<a class="icons" href="http://www.facebook.com/pages/V-Diamonds/376571259088816" target="_blank"><img src="<?php echo base_url('assets/img/icon-fb.png'); ?>"</a>
		<a class="icons" href="#"><img src="<?php echo base_url('assets/img/icon-twt.png'); ?>"</a>
	</div>	
		<div class="logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url('assets/img/logo.png'); ?>" alt=""></a></div>
		<nav>
		  <?=$Menu_Principal?>
		</nav>
</header>
