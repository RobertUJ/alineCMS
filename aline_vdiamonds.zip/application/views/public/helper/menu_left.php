<div class="row-fluid">
	<div id="header-full">
	<div class="span2"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url('assets/img/logo.png'); ?>" alt=""></a></div>
		<div class="modulo span7">
		  <?=$Menu_Principal?>
		</div>

			<div class="span5 rgt-top">
			<li><a class="link_to" href="#" page="cobertura">COBERTURA</a></li>
			    <form class="form-search">
				    <input type="text" class="input">
				    <button type="submit" class="btn">Buscar</button>
			    </form>
		    <li><a class="link_to" href="#" page="contacto">CONTACTO</a></li>
			</div> 
			<div class="languages">
<div class="lft">EN</div>
<div class="rgt">ES</div>
			</div>

	</div>
</div><!-- Fin row -->
