<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8" />
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame
		Remove this if you use the .htaccess -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<title>V / Diamonds</title>
		<meta name="description" content="" />
		<meta name="author" content="newemage.com.mx" />
		<meta name="viewport" content="width=device-width; initial-scale=1.0" />
		<?php 
		//$this->alinecms->add_css('fathom.sample');
		//$this->alinecms->add_css('animated');
		?>
		
		<!-- ************************************************************************** -->
		<!-- Le styles -->
    	<link href="<?php echo base_url('assets/css/bootstrap.css'); ?>" rel="stylesheet">
		<!-- this is the default stylesheet  ==> newemage.com.mx -->
		<link href="<?php echo base_url('assets/css/estilos.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/hover/demo.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/hover/style.css'); ?>" rel="stylesheet">
		<!--<link href="<?php echo base_url('assets/css/hover/normalize.css'); ?>" rel="stylesheet">-->
		<!-- add here our stylesheets ;)  ==> newemage.com.mx -->
		
		<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<!-- Jquery necesary -->
		<script src="<?php echo base_url('assets/js/lib/jquery.js'); ?>"></script>
		<!--<script src="<?php echo base_url('assets/js/bootstrap-carousel.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/bootstrap-transition.js'); ?>"></script>-->
		<script src="<?php echo base_url('assets/js/bootstrap-modal.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/slide/jquery-1.6.2.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/slide/jquery-easing-1.3.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/slide/layerslider.kreaturamedia.jquery.js'); ?>" type="text/javascript"></script>

		 				
		<!-- Heyy!! Designer, replace favicon.ico & apple-touch-icon.png in the folder /assets/img/ico  -->
		<link rel="shortcut icon" href="<?php echo base_url('assets/img/ico/favicon.ico'); ?>"/>
		<link rel="apple-touch-icon" href="<?php echo base_url('assets/img/ico/apple-touch-icon.png');?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('assets/img/ico/apple-touch-icon-114-precomposed.png')?>"/>
    	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('assets/img/ico/apple-touch-icon-72-precomposed.png');?>"/>
    	<link rel="apple-touch-icon-precomposed" href="<?php echo base_url('assets/img/ico/apple-touch-icon-57-precomposed.png');?>"/>
	</head>
	<body>
	