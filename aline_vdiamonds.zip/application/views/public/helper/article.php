<div class="span7 banner"><!--Aqui se cargan los banner chuy-->
	<li><a href="#"><img src="<?php echo base_url('assets/img/banner1.jpg'); ?>" alt=""></a></li>
	<li><a href="#"><img src="<?php echo base_url('assets/img/banner2.jpg'); ?>" alt=""></a></li>
</div>

<div class="span5 categorias"><!--Chuy aqui se cargan las vistas de las categorias solo van a ser cuatro-->

	<div class="image">
		<li><a href="#"><img src="<?php echo base_url('assets/img/img-1.jpg'); ?>" alt=""></a></li>
	</div>
	<div class="image">
		<li><a href="#"><img src="<?php echo base_url('assets/img/img-2.jpg'); ?>" alt=""></a></li>
	</div>
	<div class="image">
		<li><a href="#"><img src="<?php echo base_url('assets/img/img-3.jpg'); ?>" alt=""></a></li>
	</div>
	<div class="image">
		<li><a href="#"><img src="<?php echo base_url('assets/img/img-4.jpg'); ?>" alt=""></a></li>
	</div>
</div>
