<div id="myCarousel" class="carousel slide">
<!-- Carousel items -->
<div class="carousel-inner">
<div class="active item"><img src="<?php echo base_url('assets/img/slide1.png'); ?>" alt=""></div>
<div class="item orange"><img src="<?php echo base_url('assets/img/slide2.png'); ?>" alt=""></div>
<div class="item pink"><img src="<?php echo base_url('assets/img/slide1.png'); ?>" alt=""></div>

</div>
<!-- Carousel nav -->
<div class="navegacion">
<a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
<a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
</div>
</div>
 