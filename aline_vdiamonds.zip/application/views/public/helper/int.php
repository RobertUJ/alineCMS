<div id="myCarousel" class="carousel slide">

<div class="active item"><img src="<?php echo base_url('assets/img/slideb-n.jpg'); ?>" alt=""></div>

</div>
 