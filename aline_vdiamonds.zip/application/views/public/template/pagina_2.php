		<div class="exist">
		<?php $this->load->view('/public/helper/head.php'); ?>
		<?=$main_menu?>
			<div id="back-wrapper" class="container">
				
                <div id="home-wrapper" class="span12">
                
                <div id="contenido-txt">
                 
                 <h2><?=$pagina->titulo;?></h2>	
 	             <?=$pagina->contenido;?>

 	            </div>  
               
            </div>
            </div>
			<!-- Le main content -->
			
	<div id="footer-wrapper">
  
    </div>		
	<div id="mapa">
		<iframe width="2000" height="700" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/?ie=UTF8&amp;t=m&amp;ll=22.147821,-100.975213&amp;spn=0.027824,0.085788&amp;z=15&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com/?ie=UTF8&amp;t=m&amp;ll=22.147821,-100.975213&amp;spn=0.027824,0.085788&amp;z=15&amp;source=embed" style="color:#0000FF;text-align:left"></a></small>
	</div>
</div>
	</body>
</html>
