<?php $this->load->view('/public/helper/head.php'); ?>
<?php //$this->load->view('public/helper/main_menu.php'); ?>
<?=$main_menu?>
<?php $this->load->view('public/helper/slider.php'); ?>
<?php $this->load->view('/public/helper/article.php'); ?>
<?php $this->load->view('/public/helper/footer.php'); ?>
