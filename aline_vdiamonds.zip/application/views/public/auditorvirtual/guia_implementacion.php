<?=$head?>
  <body>
    <?php $data['menuactivo'] = '_2'; $this->load->view('/public/helper/menu_logged', $data); ?>
    <br/>
    <div class="container">
      <div class="row">
        <!-- contenido -->
        <div class="span12">
          <div class="page-header">
            <h2>Guia de implementación<small></small></h2>
          </div>

          <div class="row">
          	<div class="span12">
        <div style="width:595px; margin: 0 auto;" id="__ss_13035542"> <strong style="display:block;margin:12px 0 4px"><a href="http://www.slideshare.net/FabricaDeSoluciones/ba-ms-all-de-itil-implementarcomo-implementar-itilv040811" title="Como Implentar ITIL" target="_blank">Como Implentar ITIL</a></strong> <iframe src="http://www.slideshare.net/slideshow/embed_code/13035542" width="595" height="497" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen></iframe> <div style="padding:5px 0 12px"> View more <a href="http://www.slideshare.net/thecroaker/death-by-powerpoint" target="_blank">PowerPoint</a> from <a href="http://www.slideshare.net/FabricaDeSoluciones" target="_blank">Fábrica de Soluciones Rak</a> </div> </div>  	</div>
          </div>
          
        </div><!--/span-->
      </div><!--/row-->
      <hr>
    
    </div><!--/.fluid-container-->

    <?=$footer?>
      </body>
</html>