<?=$head?>
 <body>
    <?php $data['menuactivo'] = '_4'; $this->load->view('/public/helper/menu_logged', $data); ?>
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="page-header">
            <h2>Auditorias Internas</h2>
          </div>
            <div style="width:668px;margin:0 auto;" id="__ss_13035197"> <strong style="display:block;margin:12px 0 4px"><a href="http://www.slideshare.net/FabricaDeSoluciones/procedimiento-auditorias-internas" title="Procedimiento Auditorias Internas" target="_blank">Procedimiento Auditorias Internas</a></strong> <iframe src="http://www.slideshare.net/slideshow/embed_code/13035197" width="668" height="714" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen></iframe> <div style="padding:5px 0 12px"> View more <a href="http://www.slideshare.net/" target="_blank">documents</a> from <a href="http://www.slideshare.net/FabricaDeSoluciones" target="_blank">Fábrica de Soluciones Rak</a> </div> </div>
        </div><!--/span-->
      </div><!--/row-->

      <hr>



    </div><!--/.fluid-container-->
<?=$footer?>
      </body>
</html>
