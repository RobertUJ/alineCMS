    <div class="row-fluid">
    <footer>
        <p>
            
        </p>
    </footer>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- This .js file, add generic functions. -->
    <script src="<?php echo base_url('assets/admin/js/scripts_admin.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-transition.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-alert.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-modal.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-tooltip.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-dropdown.js'); ?>"></script>

 <!-- Enable only the library to be used  -->
 <!--  
    <script src="<?php echo base_url('assets/js/bootstrap-scrollspy.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-tab.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-popover.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-button.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-collapse.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-carousel.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-typeahead.js'); ?>"></script>
 -->
    </div>
