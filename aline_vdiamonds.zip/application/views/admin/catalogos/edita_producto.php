<?=$head?>
<body>
	<?=$header?>
<div class="wrapper container-fluid">
<div class="row-fluid">
	<aside id="menu_usuarios" class="span2">
		<div class="tabbable tabs-left">
			<ul class="nav nav-tabs">
				<li class=""><a href="<?php echo base_url('panel/catalogo'); ?>" >Panel de catálogos</a></li>
				<li class=""><a href="<?php echo base_url('panel/catalogo/crea_catalogo'); ?>" >Administrar Catálogos</a></li>
				<li class=""><a href="<?php echo base_url('panel/catalogo/crea_categoria'); ?>" >Administrar Categorías</a></li>
			</ul>
		</div>
	</aside>	
<div id="body_content" class="span10 panel_usuarios">
	<div class="page-header">
		<h2><?=$titulo_pagina?> <small> <?=$descripcion_pagina?></small></h2>
	</div>
<div class="row-fluid">
<!-- ***************** Formulario para crear nuevo articulo  *************** -->
<div class="span5">
	<form method="POST" action="<?php echo base_url('panel/catalogo/guarda_edicion_producto') ?>" name="frmArticuloNuevo" id="frmAddArticulo" class="form-horizontal" enctype="multipart/form-data">
		<input type="hidden" name="id_producto" value="<?php echo $id_producto; ?>">
	<?php echo validation_errors('<div class="error"><span class="label label-important">', '</span></div>'); echo '<br/>'; ?>
		<fieldset>
			<label for="nombre">Nombre del Producto</label>
			<input type="text" name='nombre' id='nombre' class="" value="<?=$nombre?>" >
			<label for="descripcion">Descripción</label>
			<textarea name="descripcion"><?=$descripcion?></textarea>
    		<label for="activo">Producto Activo</label>
    		<?php
    			$opcion_si ="";
    			$opcion_no ="";
    			if ($activo == "si")
    				$opcion_si = ' selected="selected"';
    			else
    				$opcion_no = ' selected="selected"';
    		?>
    		<select name="activo" id="activo">
    			<option value="si"<?=$opcion_si?>>Si</option>
    			<option value="no"<?=$opcion_no?>>No</option>
    		</select>
			<label for="id_catalogos">Seleccione los catalogos a asignar<br/> (Presione Ctrl para seleccionar mas de una opción)</label>
			<select class="" name="id_catalogos_cat[]" id="id_catalogos" multiple>
				<?=$catalogos?>
			</select>
			<label for="id_categorias">Seleccione las categorías a asignar<br/> (Presione Ctrl para seleccionar mas de una opción)</label>
			<select class="" name="id_categorias_cat[]" id="id_categorias" multiple>
				<?=$categorias?>
			</select>
			<br>
			<a id="add_file" href="#">Agregar otra imagen</a>
			<div id="img_files">
				<button>borrar</button>
				<input name="imagen[]" type="file" id="predeterminada"/>
			</div>
		</fieldset>
		<div id="img-previe">
			<img src="" alt="">
		</div>
	<br/>
	<div style="padding-left:20px;" class="form-actions">
	    <input  type="submit" class="btn btn-primary" name="btnGuardar" value="Guardar Producto" />
	</div>
	</form> <!-- Fin formulario para crear nuevo articulo -->
 </div>
</div>  <!-- Fin Row fluid  contenedor del form-->
</div>	<!-- Fin body_content -->
		<!-- Footer -->
		<?php $this->load->view('admin/helper/footer.php'); ?>
</div> <!-- Row fluid general" -->
</div>	<!-- End div class="wrapper container" -->
	<script type="text/javascript">
		function add_input_file(e)
		{
			e.preventDefault();
			var input_img = "<input name='imagen[]' type='file' id='normal' />";
			$("#img_files").append(input_img);
		}
		function inicio()
		{
			$("#add_file").on("click",add_input_file);
		}
		$(document).on("ready",inicio);
	</script>
</body>
</html>

